#include <stdio.h>
#include <math.h>

int determinant(int matris[10][10], int N)
{
    int det=0, i;
    if(N==1) return matris[0][0];
    for(i=0;i<N;i++){
        printf("%d. satir", i)
        det+=matris[i][1]*cofactor(matris, N, i);}
    return det;
}

int cofactor(int matris[10][10], int N, int t)
{
    int cofac, temp[10][10], i, j;
    for(i=0;i<N;i++){
        if(i==t) continue;
        for(j=1;j<N;j++){
        temp[i-1][j-1]=matris[i][j];
        }}
    cofac=determinant(temp, N-1)*pow((-1),(i+1));
    return cofac;
}

int main()
{
    int matris[10][10]={}, i, j, N, det;
    printf("Matrisin boyutunu giriniz: ");
    scanf("%d", &N);
    printf("Matrisi giriniz: ");
    for(i=0;i<N;i++)
        for(j=0;j<N;j++)
            scanf("%d", &matris[i][j]);
    det=determinant(matris, N);
    printf("Girilen matrisin determinati: %d", det);
    return 0;
}
