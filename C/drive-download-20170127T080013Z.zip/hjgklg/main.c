#include <stdio.h>

int t=0, matris[20][20];

int determinant(int matris[20][20]);

int main()
{
    int det=0, i, j, n;

    printf("Kare matrisin satir veya sutun sayisini giriniz: ");
    scanf("%d", &n);

    printf("Matrisinizin elemanlarini giriniz: ");

    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            scanf("%d", &matris[i][j]);

    if (n==1)
        det=matris[0][0];
    else if(n==2)
        det=matris[0][0]*matris[1][1]-matris[0][1]*matris[1][0];
    else
        det=determinant(matris, n);
    printf("Grilen matris:\n");
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            printf("%d  ", matris[i][j]);
        }
        printf("\n");
    }
    printf("Determinanti: %d", det);
    return 0;
}

int determinant(int matris[20][20], int n)
{
    int det=0, a, b, c, temp[20][20];

    if(t==n-1)
        return matris[t][t]*matris[n][n]-matris[t][n]*matris[n][t];

    for(b=n-t;b>=t;b--)
        for(c=n-t;c>=t;c--)
        temp[b][c]=matris[b+t][c+t];
    t++;

    for(a=0;a<n;a++)
        det+=temp[a][0]*determinant(temp, n);
    return det;
}
