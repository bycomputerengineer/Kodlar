#include <stdio.h>
#include <stdlib.h>

//�nemli not: matris parametrede x[][] �eklinde tan�mlanamaz.

void matrisyaz(int x[3][3])
{
    int i,j;
    for(i=0;i<3;i++){
        for(j=0;j<3;j++)
            printf("  %d", x[i][j]);
        printf("\n");
    }
}

void matristopla(int x[3][3], int y[3][3], int s[3][3])
{
    int i, j;
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
        s[i][j]=x[i][j]+y[i][j];
    }
}
int main()
{
    int A[3][3]={
    {1,2,3},
    {4,5,6},
    {7,8,9}
    };
    int B[3][3]={
    {10,20,30},
    {40,50,60},
    {70,80,90}
    };
    int C[3][3]={{0}};

    printf("\nA\n");
    matrisyaz(A);

    printf("\nB\n");
    matrisyaz(B);

    printf("\nC:\n");
    matrisyaz(C);

    printf("Toplama islemi yapiliyor...\n");
    matristopla(A, B, C);

    printf("\nC:\n");
    matrisyaz(C);

    return 0;
}
