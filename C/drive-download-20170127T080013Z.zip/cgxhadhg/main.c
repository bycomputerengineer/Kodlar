#include <stdio.h>
#include <stdlib.h>

int main()
{
	int matris[3][3];
	int i, j;

	printf("3*3'luk matrisi giriniz: \n");
	for(i=0;i<3;i++) {
		for(j=0;j<3;j++) {
			scanf("%d", matris[i][j]); }
		printf("\n");
	}

	printf("\nMatris \t ve \t Transposesi");
	for(i=0;i<3;i++){
		for(j=0;j<3;j++)
			printf(" %d", matris[i][j]);
		printf("\t\t");
		for(j=0;j<3;j++)
			printf(" %d", matris[j][i]);
		printf("\n");
	}
	return 0;
}
