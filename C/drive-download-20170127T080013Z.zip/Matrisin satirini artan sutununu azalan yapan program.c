#include <stdio.h>
#include <stdlib.h>

int main()
{
	int matris[100][100];
	int i, j, n, m, a, temp;
	
	printf("Girilecek matrisin boyutlarini giriniz: ");
	scanf("%d %d", &n, &m);
	for(i=0;i<n;i++){
		printf("%d. satir elemanlarini giriniz:\n", i+1);
		for(j=0;j<m;j++){
			scanf("%d", &matris[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<n;i++)
		for(a=0;a<m;a++)
			for(j=0;j<m-1;j++)
				if(matris[i][j]>matris[i][j+1]){
					temp=matris[i][j];
					matris[i][j]=matris[i][j+1];
					matris[i][j+1]=temp;
				}
	for(j=0;j<m;j++)
		for(a=0;a<n;a++)
			for(i=0;i<n-1;i++)
				if(matris[i][j]<matris[i+1][j]){
					temp=matris[i][j];
					matris[i][j]=matris[i+1][j];
					matris[i+1][j]=temp;
				}
	printf("\n\nGirilen matrisin satir elemanlarini artan,\nsutun elemanlarini ise azalan sirayla siralanmis hali: \n\n");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			printf("  %d", matris[i][j]);
		}
		printf("\n");
	}
}
