#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	int matris[100][100];
	int i, j, n, a, temp;
	srand(time(NULL));
	
	printf("\nMatirisin boyutunu giriniz: ");
	scanf("%d", &n);
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			matris[i][j]=rand()%20;
		}
	}
	
	printf("\n\nUretilen matris:\n");
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			printf("\t%d", matris[i][j]);
		printf("\n");
	}
	
	for(i=0;i<n;i++)
		for(a=0;a<n-1;a++)
			for(j=0;j<n-1;j++)
				if(matris[i][j]>matris[i][j+1]){
					temp=matris[i][j];
					matris[i][j]=matris[i][j+1];
					matris[i][j+1]=temp;
				}
	
	printf("\n\nSatirlari kucukten buyuge siralanmis matris:\n");
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			printf("\t%d", matris[i][j]);
		printf("\n");
	}
	
	for(j=0;j<n;j++)
		for(a=0;a<n-1;a++)
			for(i=0;i<n-1;i++)
				if(matris[i][j]>matris[i+1][j]){
					temp=matris[i][j];
					matris[i][j]=matris[i+1][j];
					matris[i+1][j]=temp;
				}
				
	printf("\n\nSatirlari ve sutunlari kucukten buyuge siralanmis matris:\n");
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			printf("\t%d", matris[i][j]);
		printf("\n");
	}
	
	return 0;
}
