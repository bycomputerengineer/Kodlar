#include <stdio.h>

void main()
{
    int x0, x1, y0, y1, m1, m2, x2, x3, y2, y3;
    printf("Birinci egrinin koordinatlarini girin: ");
    scanf("%d %d %d %d", &x0, &y0, &x1, &y1);
    printf("�kinci egrinin koordinatlarini girin: ");
    scanf("%d %d %d %d", &x2, &y2, &x3, &y3);
    m1=(y1-y0)/(x1-x0);
    m2=(y3-y2)/(x3-x2);
    if (m1*m2==-1) printf("�ki egri diktir");
    else printf("�ki egir dik degil");
    return 0;

}
