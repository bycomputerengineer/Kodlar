#include<stdio.h>
int main( void )
{
	// Aylari temsil etmesi icin
	// aylar adinda 12 elemanli
	// bir dizi olusturuyoruz.
	int aylar[ 12 ];
	int toplam = 0;
	int i;

	// Birinci dongu, deger atamak icindir
	for( i = 0; i < 12; i++ ) {
		printf( "%2d.Ay: ", (i+1) );
		// aylara deger at�yoruz:
		scanf( "%d", &aylar[ i ] );
	}

	// Az evvel girilen degerleri gostermek icin
	// ikinci bir dongu kurduk
	printf( "\nG�RD���N�Z DE�ERLER\n\n" );
	for( i = 0; i < 12; i++ ) {
		printf( "%2d.Ay i�in %d girdiniz\n", (i+1), aylar[i] );
		toplam += aylar[ i ];
	}

	printf( "Toplam g�ne�li g�n say�s�: %d\n", toplam );
	return 0;
}
