#include <stdio.h>

int main()
{
    int sayi1, sayi2;
    printf("Kiyaslanacak sayilari girin: ");
    scanf("%d %d", &sayi1, &sayi2);

    if (sayi1>sayi2) printf("%d", sayi1);
    else if (sayi2>sayi1) printf("%d", sayi2);
    else printf("Sayilar esittir.");

    return 0;
}
