#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	int matris[100][100];
	int i, j, n, enkucuk=21;
	srand(time(NULL));
	
	printf("\n\nUretilecek matrisin boyutunu giriniz: ");
	scanf("%d", &n);
	
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			matris[i][j]=rand()%20;
			
	printf("\n\nGirilen matris: \n");
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			printf("\t%d", matris[i][j]);
		printf("\n;");
	}
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			if(matris[i][j]<enkucuk)
				enkucuk=matris[i][j];
		printf("\n%d. satirin en kucuk elemani: %d'dir", i+1, enkucuk);
		enkucuk=21;
	}
	
	return 0;
}
