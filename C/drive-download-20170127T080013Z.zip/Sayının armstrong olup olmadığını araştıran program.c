#include <stdio.h>
#include <math.h>

int main()
{
    int sayi, b, o, y;
    printf("Uc basamakli bir sayi giriniz: ");
    scanf("%d", &sayi);
    b=sayi%10;
    o=(sayi/10)%10;
    y=sayi/100;

    printf("b: %d\no: %d\ny: %d\n", b, o, y);

    if (sayi==pow(y,3)+pow(o,3)+pow(b,3))
        printf("%d sayisi bir armstrong sayidir.", sayi);
    else
        printf("%d sayisi bir armstrong sayi degildir.", sayi);

    return 0;
}
